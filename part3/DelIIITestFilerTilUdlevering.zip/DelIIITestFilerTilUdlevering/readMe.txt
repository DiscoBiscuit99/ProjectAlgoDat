De korrekte forandringer af størrelser ved brug af Encode:

KingJamesBible.txt: 4948914 bytes -> 2771852 bytes
ScardoviaWiggsiae.dna: 1576664 bytes -> 446970 bytes
DolphinSunset.jpg: 416318 bytes -> 416727 bytes
same.txt: 100000 bytes -> 13524 bytes
oneByte.txt: 1 byte -> 1025 bytes
empty.txt: 0 bytes -> 1024 bytes

